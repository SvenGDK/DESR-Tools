This is a backup of the japanese strings represented in the XMB and system, created on a PSX DESR-5700 FW 2.11.
It only contains *.xml and *.dic files that can be restored without causing problems.

How to restore:
- Copy the "dic" and "xosd" folder to a USB drive
- Launch wLaunchELF and go to mass:/
- Mark both folders with X and press L1, select COPY
- Go back and select hdd:/
- Enter "__system" and paste both folders here
- Confirm to overwrite all .xml & .dic files

All files will be placed in their corresponding folder.
