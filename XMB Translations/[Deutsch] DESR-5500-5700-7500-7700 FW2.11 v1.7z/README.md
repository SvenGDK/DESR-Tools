# PSX-German-Translation
This is the German translation for the XMB on the PSX (DVR). Tested on DESR-5700 with Firmware 2.11.

## Deutsch: </br>
Dies ist die deutsche übersetzung des XMB auf der PSX (DVR). </br>
Getestet auf dem Model DESR-5700 mit der Firmware 2.11.

Für die Installation wird wLaunchELF benötigt um die Dateien zu ersetzen. </br>
Es werden jediglich nur einige Sprachdateien (.dic & .xml) des XMB ausgewechselt. </br>
Fehler die auf anderen Modellen auftreten könnten: Fehlender Text oder eine fehlende übersetzung.

Die Installations-Anleitung ist im 7z Archiv enthalten.
