/*
 * Copyright (c) 2007, Kevin Schoedel. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 * 	 documentation and/or other materials provided with the distribution.
 *
 * - Neither the name of Kevin Schoedel nor the names of contributors
 *   may be used to endorse or promote products derived from this software
 *   without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 * TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  1.00  2007/11/05  kps   First release.
 *  1.01  2007/11/06  kps   Fix uint types, option parsing;
 *                          added split output; other minor tweaks.
 *  1.02  2007/11/07  kps   Bug fixes; minimal data flow tracking.
 *  1.03  2007/11/15  kps   Fixed a stupid bug.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <stdarg.h>
#include <errno.h>
#include <ctype.h>
#include <time.h>


/* misc definitions */

#define SYMBOL_MAX  32
#define OPND_MAX    (4*SYMBOL_MAX)
#define LINE_MAX    256
#define DISPERBLOCK 16
#define BITS        32

#define SEXM(b,x)   (-((long)(b)) * !!((b) & (x)))
#define SEX(n,x)    (((long)(x)) | SEXM((1ul << ((n) - 1)), (x)))
#define NEG(n,x)    (-SEX((n), (x)))
#define ISNEG(n,x)  ((x) & (1ul << ((n) - 1)))

const char *memmapname(unsigned long);
const char *rangemapname(unsigned long);
const char *savestr(const char *);
void        usage(void);


/* basic types */

typedef uint8_t     BYTE;
typedef uint16_t    WORD;
typedef uint32_t    LONG;

typedef int8_t      REG;
typedef WORD        INST;
typedef LONG        ADDR;


/* registers */

const char *regx[] = {
    "<NOREG>",
    "R0",       "R1",       "R2",       "R3",
    "R4",       "R5",       "R6",       "R7",
    "R8",       "R9",       "R10",      "R11",
    "R12",      "R13",      "R14",      "R15",
    "TBR",      "RP",       "SSP",      "USP",
    "MDH",      "MDL",      "D6",       "D7",
    "D8",       "D9",       "D10",      "D11",
    "D12",      "D13",      "D14",      "D15",
    "CR0",      "CR1",      "CR2",      "CR3",
    "CR4",      "CR5",      "CR6",      "CR7",
    "CR8",      "CR9",      "CR10",     "CR11",
    "CR12",     "CR13",     "CR14",     "CR15",
    "PS",       "CCR",      "ILM",
};
const char **reg = regx + 1;

#define SPECIALS    16
#define COPROCESSOR 32

#define NOREG       -1
#define AC          13
#define FP          14
#define SP          15
#define TBR         16
#define RP          17
#define SSP         18
#define USP         19
#define MDH         20
#define MDL         21
#define PS          48
#define CCR         49
#define ILM         50


/* instructions */

enum itype {
    TYPE_A,     /* [   op          |  Rj   |  Ri   ] */
    TYPE_B,     /* [   op  |       x       |  Ri   ] */
    TYPE_C,     /* [   op          |   x   |  Ri   ] */
    TYPE_D,     /* [   op          |       x       ] */
    TYPE_E,     /* [   op                  |  Ri   ] */
    TYPE_F,     /* [   op    |     offset / 2      ] */
    TYPE_Z,     /* [   op                          ] */
    TYPE_W,     /* [               x               ] */
    TYPE_LAST
};

typedef struct opcode {
    INST         encoding;
    INST         mask;
    enum itype   type;
    const char  *name;
    const char  *format;
    const char  *action;
} OPCODE;

/* main instruction map */

const OPCODE opcode[] = {
    { 0x0000, 0xFF00, TYPE_A, "LD",     "@(A&j),i",     "iw"        },
    { 0x0100, 0xFF00, TYPE_A, "LDUH",   "@(A&j),i",     "iw"        },
    { 0x0200, 0xFF00, TYPE_A, "LDUB",   "@(A&j),i",     "iw"        },
    { 0x0300, 0xFF00, TYPE_C, "LD",     "@(S&4u),i",    "iw"        },
    { 0x0400, 0xFF00, TYPE_A, "LD",     "@j,i;Ju",      "iw"        },
    { 0x0500, 0xFF00, TYPE_A, "LDUH",   "@j,i;Ju",      "iw"        },
    { 0x0600, 0xFF00, TYPE_A, "LDUB",   "@j,i;Ju",      "iw"        },
    { 0x0700, 0xFFF0, TYPE_E, "LD",     "@S+,i",        "iwSw"      },
    { 0x0710, 0xFFF0, TYPE_E, "MOV",    "i,P",          "Pw"        },
    { 0x0780, 0xFFFF, TYPE_E, "LD",     "@S+,g",        "Sw"        },
    { 0x0781, 0xFFFF, TYPE_E, "LD",     "@S+,g",        "Sw"        },
    { 0x0782, 0xFFFF, TYPE_E, "LD",     "@S+,g",        "Sw"        },
    { 0x0783, 0xFFFF, TYPE_E, "LD",     "@S+,g",        "Sw"        },
    { 0x0784, 0xFFFF, TYPE_E, "LD",     "@S+,g",        "Sw"        },
    { 0x0785, 0xFFFF, TYPE_E, "LD",     "@S+,g",        "Sw"        },
    { 0x0790, 0xFFFF, TYPE_Z, "LD",     "@S+,P",        "Sw"        },
    { 0x0800, 0xFF00, TYPE_D, "DMOV",   "@4u,A",        "Aw"        },
    { 0x0900, 0xFF00, TYPE_D, "DMOVH",  "@2u,A",        "Aw"        },
    { 0x0A00, 0xFF00, TYPE_D, "DMOVB",  "@u,A",         "Aw"        },
    { 0x0B00, 0xFF00, TYPE_D, "DMOV",   "@4u,@-S",      "Sw"        },
    { 0x0C00, 0xFF00, TYPE_D, "DMOV",   "@4u,@A+",      "Aw"        },
    { 0x0D00, 0xFF00, TYPE_D, "DMOVH",  "@2u,@A+",      "Aw"        },
    { 0x0E00, 0xFF00, TYPE_D, "DMOVB",  "@u,@A+",       "Aw"        },
    { 0x0F00, 0xFF00, TYPE_D, "ENTER",  "#4u",          "SwFw"      },
    { 0x1000, 0xFF00, TYPE_A, "ST",     "i,@(A&j)",     ""          },
    { 0x1100, 0xFF00, TYPE_A, "STH",    "i,@(A&j)",     ""          },
    { 0x1200, 0xFF00, TYPE_A, "STB",    "i,@(A&j)",     ""          },
    { 0x1300, 0xFF00, TYPE_C, "ST",     "i,@(S&4u)",    ""          },
    { 0x1400, 0xFF00, TYPE_A, "ST",     "i,@j;Ju",      ""          },
    { 0x1500, 0xFF00, TYPE_A, "STH",    "i,@j;Ju",      ""          },
    { 0x1600, 0xFF00, TYPE_A, "STB",    "i,@j;Ju",      ""          },
    { 0x1700, 0xFFF0, TYPE_E, "ST",     "i,@-S",        "Sw"        },
    { 0x1710, 0xFFF0, TYPE_E, "MOV",    "P,i",          "iw"        },
    { 0x1780, 0xFFFF, TYPE_E, "ST",     "g,@-S",        "Sw"        },
    { 0x1781, 0xFFFF, TYPE_E, "ST",     "g,@-S",        "Sw"        },
    { 0x1782, 0xFFFF, TYPE_E, "ST",     "g,@-S",        "Sw"        },
    { 0x1783, 0xFFFF, TYPE_E, "ST",     "g,@-S",        "Sw"        },
    { 0x1784, 0xFFFF, TYPE_E, "ST",     "g,@-S",        "Sw"        },
    { 0x1785, 0xFFFF, TYPE_E, "ST",     "g,@-S",        "Sw"        },
    { 0x1790, 0xFFFF, TYPE_Z, "ST",     "P,@-S",        "Sw"        },
    { 0x1800, 0xFF00, TYPE_D, "DMOV",   "A,@4u",        ""          },
    { 0x1900, 0xFF00, TYPE_D, "DMOVH",  "A,@2u",        ""          },
    { 0x1A00, 0xFF00, TYPE_D, "DMOVB",  "A,@u",         ""          },
    { 0x1B00, 0xFF00, TYPE_D, "DMOV",   "@S+,@4u",      "Sw"        },
    { 0x1C00, 0xFF00, TYPE_D, "DMOV",   "@A+,@4u",      "Aw"        },
    { 0x1D00, 0xFF00, TYPE_D, "DMOVH",  "@A+,@2u",      "Aw"        },
    { 0x1E00, 0xFF00, TYPE_D, "DMOVB",  "@A+,@u",       "Aw"        },
    { 0x1F00, 0xFF00, TYPE_D, "INT",    "#u",           "("         },
    { 0x2000, 0xF000, TYPE_B, "LD",     "@(F&4s),i",    "iw"        },
    { 0x3000, 0xF000, TYPE_B, "ST",     "i,@(F&4s)",    ""          },
    { 0x4000, 0xF000, TYPE_B, "LDUH",   "@(F&2s),i",    "iw"        },
    { 0x5000, 0xF000, TYPE_B, "STH",    "i,@(F&2s)",    ""          },
    { 0x6000, 0xF000, TYPE_B, "LDUB",   "@(F&s),i",     "iw"        },
    { 0x7000, 0xF000, TYPE_B, "STB",    "i,@(F&s)",     ""          },
    { 0x8000, 0xFF00, TYPE_C, "BANDL",  "#u,@i;Iu",     ""          },
    { 0x8100, 0xFF00, TYPE_C, "BANDH",  "#u,@i;Iu",     ""          },
    { 0x8200, 0xFF00, TYPE_A, "AND",    "j,i",          "iw"        },
    { 0x8300, 0xFF00, TYPE_D, "ANDCCR", "#u",           ""          },
    { 0x8400, 0xFF00, TYPE_A, "AND",    "j,@i;Iu",      ""          },
    { 0x8500, 0xFF00, TYPE_A, "ANDH",   "j,@i;Iu",      ""          },
    { 0x8600, 0xFF00, TYPE_A, "ANDB",   "j,@i;Iu",      ""          },
    { 0x8700, 0xFF00, TYPE_D, "STILM",  "#u",           ""          },
    { 0x8800, 0xFF00, TYPE_C, "BTSTL",  "#u,@i;Iu",     ""          },
    { 0x8900, 0xFF00, TYPE_C, "BTSTH",  "#u,@i;Iu",     ""          },
    { 0x8A00, 0xFF00, TYPE_A, "XCHB",   "@j,i;Ju",      "iw"        },
    { 0x8B00, 0xFF00, TYPE_A, "MOV",    "j,i",          "iw"        },
    { 0x8C00, 0xFF00, TYPE_D, "LDM0",   "z",            "Sw"        },
    { 0x8D00, 0xFF00, TYPE_D, "LDM1",   "y",            "Sw"        },
    { 0x8E00, 0xFF00, TYPE_D, "STM0",   "xz",           "Sw"        },
    { 0x8F00, 0xFF00, TYPE_D, "STM1",   "xy",           "Sw"        },
    { 0x9000, 0xFF00, TYPE_C, "BORL",   "#u,@i;Iu",     ""          },
    { 0x9100, 0xFF00, TYPE_C, "BORH",   "#u,@i;Iu",     ""          },
    { 0x9200, 0xFF00, TYPE_A, "OR",     "j,i",          "iw"        },
    { 0x9300, 0xFF00, TYPE_D, "ORCCR",  "#u",           ""          },
    { 0x9400, 0xFF00, TYPE_A, "OR",     "j,@i;Iu",      ""          },
    { 0x9500, 0xFF00, TYPE_A, "ORH",    "j,@i;Iu",      ""          },
    { 0x9600, 0xFF00, TYPE_A, "ORB",    "j,@i;Iu",      ""          },
    { 0x9700, 0xFFF0, TYPE_E, "JMP",    "@i;Iu",        "!"         },
    { 0x9710, 0xFFF0, TYPE_E, "CALL",   "@i;Iu",        "("         },
    { 0x9720, 0xFFFF, TYPE_Z, "RET",    "",             ")"         },
    { 0x9730, 0xFFFF, TYPE_Z, "RETI",   "",             ")"         },
    { 0x9740, 0xFFF0, TYPE_E, "DIV0S",  "i",            "iw"        },
    { 0x9750, 0xFFF0, TYPE_E, "DIV0U",  "i",            "iw"        },
    { 0x9760, 0xFFF0, TYPE_E, "DIV1",   "i",            "iw"        },
    { 0x9770, 0xFFF0, TYPE_E, "DIV2",   "i",            "iw"        },
    { 0x9780, 0xFFF0, TYPE_E, "EXTSB",  "i",            "iw"        },
    { 0x9790, 0xFFF0, TYPE_E, "EXTUB",  "i",            "iw"        },
    { 0x97A0, 0xFFF0, TYPE_E, "EXTSH",  "i",            "iw"        },
    { 0x97B0, 0xFFF0, TYPE_E, "EXTUH",  "i",            "iw"        },
    { 0x9800, 0xFF00, TYPE_C, "BEORL",  "#u,@i;Iu",     ""          },
    { 0x9900, 0xFF00, TYPE_C, "BEORH",  "#u,@i;Iu",     ""          },
    { 0x9A00, 0xFF00, TYPE_A, "EOR",    "j,i",          "iw"        },
    { 0x9B00, 0xFF00, TYPE_C, "LDI:20", "X#u,i",        "iv"        },
    { 0x9C00, 0xFF00, TYPE_A, "EOR",    "j,@i;Iu",      ""          },
    { 0x9D00, 0xFF00, TYPE_A, "EORH",   "j,@i;Iu",      ""          },
    { 0x9E00, 0xFF00, TYPE_A, "EORB",   "j,@i;Iu",      ""          },
    { 0x9F00, 0xFFF0, TYPE_E, "JMP:D",  "@i;Iu",        "_!"        },
    { 0x9F10, 0xFFF0, TYPE_E, "CALL:D", "@i;Iu",        "_("        },
    { 0x9F20, 0xFFFF, TYPE_Z, "RET:D",  "",             "_)"        },
    { 0x9F30, 0xFFFF, TYPE_Z, "INTE",   "",             ""          },
    { 0x9F60, 0xFFFF, TYPE_Z, "DIV3",   "",             ""          },
    { 0x9F70, 0xFFFF, TYPE_Z, "DIV4S",  "",             ""          },
    { 0x9F80, 0xFFF0, TYPE_E, "LDI:32", "XX#u,i",       "iv"        },
    { 0x9F90, 0xFFFF, TYPE_Z, "LEAVE",  "",             ""          },
    { 0x9FA0, 0xFFFF, TYPE_Z, "NOP",    "",             ""          },
    { 0x9FC0, 0xFFF0, TYPE_E, "COPOP",  "Y#u,#c,l,k",   ""          },
    { 0x9FD0, 0xFFF0, TYPE_E, "COPLD",  "Y#u,#c,j,k",   ""          },
    { 0x9FE0, 0xFFF0, TYPE_E, "COPST",  "Y#u,#c,l,i",   "iw"        },
    { 0x9FF0, 0xFFF0, TYPE_E, "COPSV",  "Y#u,#c,l,i",   "iw"        },
    { 0xA000, 0xFF00, TYPE_C, "ADDN",   "#u,i",         "iw"        },
    { 0xA100, 0xFF00, TYPE_C, "ADDN2",  "#n,i",         "iw"        },
    { 0xA200, 0xFF00, TYPE_A, "ADDN",   "j,i",          "iw"        },
    { 0xA300, 0xFF00, TYPE_D, "ADDSP",  "#4s",          "Sw"        },
    { 0xA400, 0xFF00, TYPE_C, "ADD",    "#u,i",         "iw"        },
    { 0xA500, 0xFF00, TYPE_C, "ADD2",   "#n,i",         "iw"        },
    { 0xA600, 0xFF00, TYPE_A, "ADD",    "j,i",          "iw"        },
    { 0xA700, 0xFF00, TYPE_A, "ADDC",   "j,i",          "iw"        },
    { 0xA800, 0xFF00, TYPE_C, "CMP",    "#u,i",         "iw"        },
    { 0xA900, 0xFF00, TYPE_C, "CMP2",   "#n,i",         "iw"        },
    { 0xAA00, 0xFF00, TYPE_A, "CMP",    "j,i",          "iw"        },
    { 0xAB00, 0xFF00, TYPE_A, "MULU",   "j,i",          "iw"        },
    { 0xAC00, 0xFF00, TYPE_A, "SUB",    "j,i",          "iw"        },
    { 0xAD00, 0xFF00, TYPE_A, "SUBC",   "j,i",          "iw"        },
    { 0xAE00, 0xFF00, TYPE_A, "SUBN",   "j,i",          "iw"        },
    { 0xAF00, 0xFF00, TYPE_A, "MUL",    "j,i",          "iw"        },
    { 0xB000, 0xFF00, TYPE_C, "LSR",    "#d,i",         "iw"        },
    { 0xB100, 0xFF00, TYPE_C, "LSR2",   "#d,i",         "iw"        },
    { 0xB200, 0xFF00, TYPE_A, "LSR",    "j,i",          "iw"        },
    { 0xB300, 0xFFF0, TYPE_A, "MOV",    "i,h",          ""          },
    { 0xB310, 0xFFF0, TYPE_A, "MOV",    "i,h",          ""          },
    { 0xB320, 0xFFF0, TYPE_A, "MOV",    "i,h",          ""          },
    { 0xB330, 0xFFF0, TYPE_A, "MOV",    "i,h",          ""          },
    { 0xB340, 0xFFF0, TYPE_A, "MOV",    "i,h",          ""          },
    { 0xB350, 0xFFF0, TYPE_A, "MOV",    "i,h",          ""          },
    { 0xB400, 0xFF00, TYPE_C, "LSL",    "#d,i",         "iw"        },
    { 0xB500, 0xFF00, TYPE_C, "LSL2",   "#d,i",         "iw"        },
    { 0xB600, 0xFF00, TYPE_A, "LSL",    "j,i",          "iw"        },
    { 0xB700, 0xFFF0, TYPE_A, "MOV",    "h,i",          "iw"        },
    { 0xB710, 0xFFF0, TYPE_A, "MOV",    "h,i",          "iw"        },
    { 0xB720, 0xFFF0, TYPE_A, "MOV",    "h,i",          "iw"        },
    { 0xB730, 0xFFF0, TYPE_A, "MOV",    "h,i",          "iw"        },
    { 0xB740, 0xFFF0, TYPE_A, "MOV",    "h,i",          "iw"        },
    { 0xB750, 0xFFF0, TYPE_A, "MOV",    "h,i",          "iw"        },
    { 0xB800, 0xFF00, TYPE_C, "ASR",    "#d,i",         "iw"        },
    { 0xB900, 0xFF00, TYPE_C, "ASR2",   "#d,i",         "iw"        },
    { 0xBA00, 0xFF00, TYPE_A, "ASR",    "j,i",          "iw"        },
    { 0xBB00, 0xFF00, TYPE_A, "MULUH",  "j,i",          "iw"        },
    { 0xBC00, 0xFF00, TYPE_C, "LDRES",  "@i+,#u;Iu",    ""          },
    { 0xBD00, 0xFF00, TYPE_C, "STRES",  "#u,@i+;Iu",    ""          },
    { 0xBF00, 0xFF00, TYPE_A, "MULH",   "j,i",          "iw"        },
    { 0xC000, 0xF000, TYPE_B, "LDI:8",  "#u,i",         "iw"        },
    { 0xD000, 0xF800, TYPE_F, "CALL",   "2ru",          "("         },
    { 0xD800, 0xF800, TYPE_F, "CALL:D", "2ru",          "_("        },
    { 0xE000, 0xFF00, TYPE_D, "BRA",    "2ru",          "!"         },
    { 0xE100, 0xFF00, TYPE_D, "BNO",    "2ru",          "?"         },
    { 0xE200, 0xFF00, TYPE_D, "BEQ",    "2ru",          "?"         },
    { 0xE300, 0xFF00, TYPE_D, "BNE",    "2ru",          "?"         },
    { 0xE400, 0xFF00, TYPE_D, "BC",     "2ru",          "?"         },
    { 0xE500, 0xFF00, TYPE_D, "BNC",    "2ru",          "?"         },
    { 0xE600, 0xFF00, TYPE_D, "BN",     "2ru",          "?"         },
    { 0xE700, 0xFF00, TYPE_D, "BP",     "2ru",          "?"         },
    { 0xE800, 0xFF00, TYPE_D, "BV",     "2ru",          "?"         },
    { 0xE900, 0xFF00, TYPE_D, "BNV",    "2ru",          "?"         },
    { 0xEA00, 0xFF00, TYPE_D, "BLT",    "2ru",          "?"         },
    { 0xEB00, 0xFF00, TYPE_D, "BGE",    "2ru",          "?"         },
    { 0xEC00, 0xFF00, TYPE_D, "BLE",    "2ru",          "?"         },
    { 0xED00, 0xFF00, TYPE_D, "BGT",    "2ru",          "?"         },
    { 0xEE00, 0xFF00, TYPE_D, "BLS",    "2ru",          "?"         },
    { 0xEF00, 0xFF00, TYPE_D, "BHI",    "2ru",          "?"         },
    { 0xF000, 0xFF00, TYPE_D, "BRA:D",  "2ru",          "_!"        },
    { 0xF100, 0xFF00, TYPE_D, "BNO:D",  "2ru",          "_?"        },
    { 0xF200, 0xFF00, TYPE_D, "BEQ:D",  "2ru",          "_?"        },
    { 0xF300, 0xFF00, TYPE_D, "BNE:D",  "2ru",          "_?"        },
    { 0xF400, 0xFF00, TYPE_D, "BC:D",   "2ru",          "_?"        },
    { 0xF500, 0xFF00, TYPE_D, "BNC:D",  "2ru",          "_?"        },
    { 0xF600, 0xFF00, TYPE_D, "BN:D",   "2ru",          "_?"        },
    { 0xF700, 0xFF00, TYPE_D, "BP:D",   "2ru",          "_?"        },
    { 0xF800, 0xFF00, TYPE_D, "BV:D",   "2ru",          "_?"        },
    { 0xF900, 0xFF00, TYPE_D, "BNV:D",  "2ru",          "_?"        },
    { 0xFA00, 0xFF00, TYPE_D, "BLT:D",  "2ru",          "_?"        },
    { 0xFB00, 0xFF00, TYPE_D, "BGE:D",  "2ru",          "_?"        },
    { 0xFC00, 0xFF00, TYPE_D, "BLE:D",  "2ru",          "_?"        },
    { 0xFD00, 0xFF00, TYPE_D, "BGT:D",  "2ru",          "_?"        },
    { 0xFE00, 0xFF00, TYPE_D, "BLS:D",  "2ru",          "_?"        },
    { 0xFF00, 0xFF00, TYPE_D, "BHI:D",  "2ru",          "_?"        },
    {      0,      0, TYPE_Z, NULL,                                 }
};

const OPCODE opaltstack[] = {
    { 0x0700, 0xFFF0, TYPE_E, "POP",    "i",            ""          },
    { 0x0780, 0xFFFF, TYPE_E, "POP",    "g",            ""          },
    { 0x0781, 0xFFFF, TYPE_E, "POP",    "g",            ""          },
    { 0x0782, 0xFFFF, TYPE_E, "POP",    "g",            ""          },
    { 0x0783, 0xFFFF, TYPE_E, "POP",    "g",            ""          },
    { 0x0784, 0xFFFF, TYPE_E, "POP",    "g",            ""          },
    { 0x0785, 0xFFFF, TYPE_E, "POP",    "g",            ""          },
    { 0x0790, 0xFFFF, TYPE_Z, "POP",    "P",            ""          },
    { 0x0B00, 0xFF00, TYPE_D, "PUSH",   "@4u",          ""          },
    { 0x1700, 0xFFF0, TYPE_E, "PUSH",   "i",            ""          },
    { 0x1780, 0xFFFF, TYPE_E, "PUSH",   "g",            ""          },
    { 0x1781, 0xFFFF, TYPE_E, "PUSH",   "g",            ""          },
    { 0x1782, 0xFFFF, TYPE_E, "PUSH",   "g",            ""          },
    { 0x1783, 0xFFFF, TYPE_E, "PUSH",   "g",            ""          },
    { 0x1784, 0xFFFF, TYPE_E, "PUSH",   "g",            ""          },
    { 0x1785, 0xFFFF, TYPE_E, "PUSH",   "g",            ""          },
    { 0x1790, 0xFFFF, TYPE_Z, "PUSH",   "P",            ""          },
    { 0x1B00, 0xFF00, TYPE_D, "POP",    "@u",           ""          },
    { 0x8C00, 0xFF00, TYPE_D, "POP",    "z",            ""          },
    { 0x8D00, 0xFF00, TYPE_D, "POP",    "y",            ""          },
    { 0x8E00, 0xFF00, TYPE_D, "PUSH",   "xz",           ""          },
    { 0x8F00, 0xFF00, TYPE_D, "PUSH",   "xy",           ""          },
    {      0,      0, TYPE_Z, NULL,                                 }
};

const OPCODE opaltshift[] = {
    { 0xB100, 0xFF00, TYPE_C, "LSR",    "#bd,i",        "iw"        },
    { 0xB500, 0xFF00, TYPE_C, "LSL",    "#bd,i",        "iw"        },
    { 0xB900, 0xFF00, TYPE_C, "ASR",    "#bd,i",        "iw"        },
    {      0,      0, TYPE_Z, NULL,                                 }
};

const OPCODE opaltdmov[] = {
    { 0x0800, 0xFF00, TYPE_D, "LD",     "@4u,A",        ""          },
    { 0x0900, 0xFF00, TYPE_D, "LDUH",   "@2u,A",        ""          },
    { 0x0A00, 0xFF00, TYPE_D, "LDUB",   "@u,A",         ""          },
    { 0x1800, 0xFF00, TYPE_D, "ST",     "A,@4u",        ""          },
    { 0x1900, 0xFF00, TYPE_D, "STUH",   "A,@2u",        ""          },
    { 0x1A00, 0xFF00, TYPE_D, "STUB",   "A,@u",         ""          },
    {      0,      0, TYPE_Z, NULL,                                 }
};

const OPCODE opaltspecial[] = {
    { 0x8300, 0xFF00, TYPE_D, "AND",    "#u,C",         "Cw"        },
    { 0x8700, 0xFF00, TYPE_D, "MOV",    "#u,M",         ""          },
    { 0x9300, 0xFF00, TYPE_D, "OR",     "#u,C",         "Cw"        },
    { 0xA300, 0xFF00, TYPE_D, "ADD",    "#4s,S",        ""          },
    {      0,      0, TYPE_Z, NULL,                                 }
};

const OPCODE opdata[] = {
    { 0x0000, 0x0000, TYPE_W, "DW",     "u;a",          ""          },
    { 0x0000, 0x0000, TYPE_W, "DL",     "Xu;a",         ""          },
    { 0x0000, 0x0000, TYPE_W, "DL",     "Xu;a",         ""          },
    { 0x0000, 0x0000, TYPE_W, "DL",     "Xu;INT #v",    ""          },
    { 0x0000, 0x0000, TYPE_W, "DR",     "Xq;f",         ""          },
    {      0,      0, TYPE_Z, NULL,                                 }
};


#define MD_WORD         00
#define MD_LONG         01
#define MD_LONGNUM      02
#define MD_VECTOR       03
#define MD_RATIONAL     04

const OPCODE *decode[0x10000];


/* output formatting */

struct {
    const char *nxt;
    const char *imm;
    const char *and;
    const char *inc;
    const char *dec;
    const char *mem;
    const char *par;
    const char *ens;
    const char *asc;
    const char *ud;
    const char *u[BITS + 1];
    const char *n[BITS + 1];
} fmt = {
    ",", "#", ",", "+", "-", "@", "(", ")", "%c", "%u"
};


/* string table */

#define STRBUCKETS  4096

struct savestr {
    struct savestr *next;
    const char *s;
} *strs[STRBUCKETS];


/* address mapping */

typedef struct range {
    struct range *next;
    unsigned long start;
    unsigned long end;
    unsigned long data;
} RANGE;

typedef struct map {
    int           opt;
    const char   *name;
    const char   *(*mapname)(unsigned long);
    struct range *head;
} MAP;


#define MD_OPMAX        8
#define MD_OPLEN        3
#define MD_OPMASK       ((1ul<<MD_OPLEN)-1)

#define MD_TYPEBIT      0
#define MD_TYPELEN      4
#define MD_TYPEMASK     ((1ul<<MD_TYPELEN)-1)
#define MD_LENGTHBIT    (MD_TYPEBIT + MD_TYPELEN)
#define MD_LENGTHLEN    4
#define MD_LENGTHMASK   ((1ul<<MD_LENGTHLEN)-1)
#define MD_SPECBIT      (MD_LENGTHBIT + MD_LENGTHLEN)
#define MD_SPECLEN      (MD_OPLEN * MD_OPMAX)

#define MEMTYPE_NONE    0
#define MEMTYPE_UNKNOWN 1
#define MEMTYPE_CODE    2
#define MEMTYPE_DATA    3
#define MKDATA(n,s)     (MEMTYPE_DATA|((n)<<MD_LENGTHBIT)|((s)<<MD_SPECBIT))


/* disassembly */

#define DF_FLOW     0x01
#define DF_BREAK    0x02
#define DF_DELAY    0x04
#define DF_BRANCH   0x10
#define DF_JUMP     0x20
#define DF_CALL     0x40
#define DF_RETURN   0x80

#define DF_TO_KEEP  (DF_FLOW|DF_BRANCH|DF_JUMP|DF_CALL|DF_RETURN)
#define DF_TO_COPY  (DF_DELAY)
#define DF_TO_DELAY (DF_BREAK)

typedef struct dis {
    unsigned short flags;
    ADDR           pc;
    WORD           data[3];
    int8_t         n;        /* number of data[] words */
    int8_t         w;        /* width of x in bits */
    uint8_t        c;        /* coprocessor operation */
    REG            i;        /* Ri/Rs operand */
    REG            j;        /* Rj operand */
    ADDR           x;        /* constant operand */
    const OPCODE  *opcode;   /* decoded opcode */
    const char    *opnds;    /* formatted operand list */
    const char    *comment;  /* optional comment */
    RANGE         *memrange; /* memory range */
} DIS;

typedef struct distate {
    unsigned short flags;
    ADDR           pc;
    RANGE         *memrange;
    unsigned long  rvalid;
    ADDR           reg[32];
} DISTATE;

#define OKREG(n)        (((n)>=0)&&((n)<32))
#define ISVALID(p,n)    (OKREG((n))?((p)->rvalid & (1 << (n))):0)
#define SETVALID(p,n)   (OKREG((n))?((p)->rvalid |= (1 << (n))):0)
#define SETINVALID(p,n) (OKREG((n))?((p)->rvalid &=~(1 << (n))):0)

/* output options */

#define OF_ALTREG       0x00000001  /* use AC, SP, FP for R13-R15 */
#define OF_ALTDMOV      0x00000002  /* use LD/ST for some DMOV etc */
#define OF_ALTSHIFT     0x00000004  /* use large constant for LSL2 etc */
#define OF_ALTSTACK     0x00000008  /* use PUSH/POP */
#define OF_ALTSPECIALS  0x00000010  /* use special register operation */
#define OF_CSTYLE       0x00000100  /* use C style operand syntax */
#define OF_HEXDOLLAR    0x00000200  /* use $0 syntax for hexadecimal numbers */
#define OF_FILEMAP      0x00010000  /* write file map */
#define OF_MEMORYMAP    0x00020000  /* write memory map */
#define OF_SYMTAB       0x00040000  /* write symbol table */
#define OF_XREF         0x00080000  /* write cross reference */
#define OF_VERBOSE      0x01000000  /* verbose messages */
#define OF_DEBUG        0x02000000  /* debug disassembler miscellaneous */
#define OF_INVERT       0x80000000  /* parsing: invert sense of flag */

struct flag {
    int           width;
    unsigned long value;
    const char   *flag;
    const char   *desc;
} outflags[] = {
    { 2, OF_XREF,           "crossreference",   NULL                        },
    { 2, OF_CSTYLE,         "cstyle",           "use C-style operands"      },
    { 6, OF_DEBUG,          "debug",            NULL                        },
    { 2, OF_ALTDMOV,        "dmov",             "use alternates for DMOV"   },
    { 2, OF_HEXDOLLAR,      "dollar",           "use $ for hexadecimal"     },
    { 2, OF_FILEMAP,        "filemap",          "generate input file map"   },
    { 2, OF_MEMORYMAP,      "memorymap",        "generate memory map"       },
    { 2, OF_ALTREG,         "register",         "use AC, FP, SP"            },
    { 2, OF_ALTSHIFT,       "shift",            "use large shift constants" },
    { 2, OF_ALTSPECIALS,    "specials",         "use special registers"     },
    { 2, OF_ALTSTACK,       "stack",            "use PUSH and POP"          },
    { 2, OF_SYMTAB,         "symbols",          NULL                        },
    { 1, OF_VERBOSE,        "verbose",          NULL                        },
    { 1, OF_XREF,           "xreference",       NULL                        },
    { 0 }
};


char *cmdname           = "dfr";
char *version           = "1.03";

const char *opt_infile  = NULL;
const char *opt_outfile = NULL;
uint32_t    opt_outflag = 0;
int         opt_little  = 0;
int         opt_split   = 0;

const char *outbase     = NULL;
const char *outext      = NULL;
FILE       *infp        = NULL;
FILE       *outfp       = NULL;
           
MAP         filemap     = { 'i', "File map",        NULL,         NULL };
MAP         memmap      = { 'm', "Memory map",      memmapname,   NULL };
MAP         rangemap    = { 'd', "Selected ranges", rangemapname, NULL };
           
DIS        *freedises   = NULL;
const char *starttime   = NULL;


/* output */

int
openoutput(ADDR pc, int usepc, const char *ext)
{
    char *s, outname[FILENAME_MAX];
    const char *t, *dot;

    if (outfp && !opt_split)
        return 0;
    if (!outbase) {
        if (opt_outfile) {
            if (!strcmp(opt_outfile, "-")) {
                opt_split = 0;
                outfp = stdout;
                return 1;
            }
            snprintf(outname, FILENAME_MAX, "%s", opt_outfile);
        }
        else {
            if (!(t = strrchr(opt_infile, '/')))
                t = opt_infile;
            else
                ++t;
            snprintf(outname, FILENAME_MAX, "%s", t);
            if ((s = strrchr(outname, '.')) != NULL) {
                *s++ = 0;
                if (*s)
                    outext = savestr(s);
            }
        }
        outbase = savestr(outname);
    }
    if (!ext)
        ext = outext;
    if (ext) {
        dot = ".";
    }
    else {
        ext = "";
        dot = "";
    }
    if (usepc)
        snprintf(outname, FILENAME_MAX, "%s-%08lX%s%s", outbase, pc, dot, ext);
    else
        snprintf(outname, FILENAME_MAX, "%s%s%s", outbase, dot, ext);
    if (outfp)
        fclose(outfp);
    if (!(outfp = fopen(outname, "w"))) {
        fprintf(stderr, "%s: cannot open output file \"%s\": %s\n",
            cmdname, outname, strerror(errno));
        exit(1);
    }
    return 1;
}

void
info(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vfprintf(outfp, fmt, ap);
    fprintf(outfp, "\n");
    va_end(ap);
    if (opt_outflag & (OF_VERBOSE|OF_DEBUG)) {
        va_start(ap, fmt);
        vfprintf(stderr, fmt, ap);
        fprintf(stderr, "\n");
        va_end(ap);
    }
}

void
nl(void)
{
    fputc('\n', outfp);
}

void
error(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    fprintf(outfp, "*** ");
    vfprintf(outfp, fmt, ap);
    fprintf(outfp, "\n");
    va_end(ap);
    va_start(ap, fmt);
    fprintf(stderr, "%s: ", cmdname);
    vfprintf(stderr, fmt, ap);
    fprintf(stderr, "\n");
    va_end(ap);
}

void
header(void)
{
    fprintf(outfp, "DFR %s\n", version);
    fprintf(outfp, "  Date:   %s\n", starttime);
    fprintf(outfp, "  Input:  %s\n", opt_infile);
    fprintf(outfp, "  Output: %s\n", opt_outfile);
    nl();
}

int
asc(int c)
{
    c &= 0xFF;
    return isprint(c) ? c : '.';
}


/* memory management */

void *
myalloc(size_t size, const char *reason)
{
    void *p = malloc(size);
    if (!p) {
        fprintf(stderr, "Cannot allocate %lu bytes for %s\n", size, reason);
        exit(1);
    }
    return p;
}


/* disassembly record */

void
freedis(DIS *dp)
{
    *(DIS **)dp = freedises;
    freedises = dp;
}

DIS *
newdis(ADDR pc, RANGE *mrp)
{
    DIS *dp;
    int i;

    if (!freedises) {
        dp = myalloc (DISPERBLOCK * sizeof (DIS), "disassembled instructions");
        for (i = 0; i < DISPERBLOCK; ++i)
            freedis(dp++);
    }
    dp = freedises;
    freedises = *(DIS **)dp;

    dp->flags = 0;
    dp->pc = pc;
    dp->data[0] = dp->data[1] = dp->data[2] = 0xDEAD;
    dp->n = 0;
    dp->w = 0;
    dp->c = 0;
    dp->i = NOREG;
    dp->j = NOREG;
    dp->x = 0;
    dp->opnds = NULL;
    dp->comment = NULL;
    dp->memrange = mrp;
    return dp;
}

void
writedis(FILE *fp, DIS *dp)
{
    int i;

    fprintf(fp, "%08lX ", dp->pc);
    for (i = 0; i < 3; ++i)
        if (i < dp->n)
            fprintf(fp, " %04X", dp->data[i]);
        else
            fprintf(fp, "     ");
    if (dp->flags & DF_DELAY)
        fprintf(fp, "  %-12s  %-6s %s", "", dp->opcode->name, dp->opnds);
    else
        fprintf(fp, "  %-12s %-7s %s", "", dp->opcode->name, dp->opnds);
    if (dp->comment) {
        int n = 20 - strlen(dp->opnds);
        if (n < 0)
            n = 0;
        fprintf(fp, "%*c; %s", n, ' ', dp->comment);
    }
    fprintf(fp, "\n");
    if (dp->flags & DF_BREAK)
        fprintf(fp, "\n");
}


/* string table */

uint32_t
strhash(const char *s)
{
    uint32_t r = 0;
    int c;
    while (c = *s++)
        r = (r << 1) | ((r >> 31) & 1) | c;
    return r;
}

const char *
savestr(const char *s)
{
    uint32_t bucket;
    struct savestr *p;
    size_t n;

    bucket = strhash(s) % STRBUCKETS;
    for (p = strs[bucket]; p; p = p->next)
        if (!strcmp(p->s, s))
            break;
    if (!p) {
        n = 1 + strlen(s);
        p = myalloc(n + sizeof (struct savestr), "string");
        p->s = strncpy(((char *)p) + sizeof (struct savestr), s, n);
        p->next = strs[bucket];
        strs[bucket] = p;
    }
    return p->s;
}

void
dumpstrs(void)
{
    uint32_t bucket;
    struct savestr *p;

    for (bucket = 0; bucket < STRBUCKETS; ++bucket) {
        if ((p = strs[bucket]) != NULL) {
            fprintf(stderr, "%lu:\n", bucket);
            for (; p; p = p->next)
                fprintf(stderr, "  %s\n", p->s);
        }
    }
}


/* address maps */

const char *
memmapname(unsigned long n)
{
    static char buf[16];
    char *s;
    unsigned long specs;
    int i, speclen;

    switch (n & MD_TYPEMASK) {
    case MEMTYPE_NONE:      return "NONE";
    case MEMTYPE_UNKNOWN:   return "UNKNOWN";
    case MEMTYPE_CODE:      return "CODE";
    case MEMTYPE_DATA:
        strcpy(buf, "DATA:");
        s = buf + 5;
        speclen = (n >> MD_LENGTHBIT) & MD_LENGTHMASK;
        specs = n >> MD_SPECBIT;
        for (i = 0; i < speclen; ++i) {
            switch (specs & MD_OPMASK) {
            case MD_LONG:     *s++ = 'L'; break;
            case MD_LONGNUM:  *s++ = 'N'; break;
            case MD_RATIONAL: *s++ = 'R'; break;
            case MD_VECTOR:   *s++ = 'V'; break;
            case MD_WORD:     *s++ = 'W'; break;
            default:          *s++ = '?'; break;
            }
            specs >>= MD_OPLEN;
        }
        *s = 0;
        return buf;
    default:
        snprintf(buf, 16, "?%x?", n);
        return buf;
    }
}

const char *
rangemapname(unsigned long n)
{
    return NULL;
}

size_t
fmtmap(char *buf, size_t len, struct map *map, struct range *rp)
{
    const char *r;
    size_t n;

    if (!rp) {
        *buf = 0;
        return 0;
    }

    if (map) {
        n = snprintf(buf, len, "  -%c ", map->opt);
        buf += n;
        len -= n;
    }
    n = snprintf(buf, len, "0x%08lX-0x%08lX", rp->start, rp->end);
    buf += n;
    len -= n;
    if (map) {
        if (!map->mapname)
            return n + snprintf(buf, len, "=0x%08lX", rp->data);
        if ((r = (*map->mapname)(rp->data)) != NULL)
            return n + snprintf(buf, len, "=%s", r);
    }
    return n;
}

void
dispmap(struct map *map, struct range *rp)
{
    char buf[LINE_MAX];
    fmtmap(buf, LINE_MAX, map, rp);
    fprintf(outfp, "%s\n", buf);
}

void
dumpmap(struct map *map)
{
    struct range *rp;

    fprintf(outfp, "%s:\n", map->name);
    for (rp = map->head; rp; rp = rp->next) {
        dispmap(map, rp);
    }
    nl();
}

void
insmap(struct map *map,
       unsigned long start, unsigned long end, unsigned long data)
{
    struct range *np, *rp;

    np = (struct range *) myalloc(sizeof (struct range), "map range");
    np->next  = NULL;
    np->start = start;
    np->end   = end;
    np->data  = data;
    if (!map->head || (start < map->head->start)) {
        np->next = map->head;
        map->head = np;
        return;
    }
    for (rp = map->head; rp->next; rp = rp->next) {
        if (start < rp->next->start) {
            np->next = rp->next;
            rp->next = np;
            return;
        }
    }
    rp->next = np;
}

void
fixmap(struct map *map, unsigned long data)
{
    struct range *rp, *dp;
    unsigned long next, maxlength;

    if (!map->head)
        insmap(map, 0, 0xFFFFFFFF, data);
    for (rp = map->head; rp; rp = rp->next) {
        if (rp->next && rp->end >= rp->next->start) {
            error("Range 0x%08lX-0x%08lX overlaps 0x%08lX-0x%08lX\n",
                rp->start, rp->end, rp->next->start, rp->next->end);
            rp->next->start = rp->end + 1;
            if (rp->next->start > rp->next->end) {
                dp = rp->next;
                rp->next = rp->next->next;
                free(dp);
            }
        }
    }
}

void
fillmap(struct map *map, unsigned long data)
{
    struct range *np, *rp;
    unsigned long start, end;
    int fill;

    for (rp = map->head; rp; rp = rp->next) {
        fill = 0;
        if (rp == map->head && rp->start != 0) {
            np = (struct range *) myalloc(sizeof (struct range), "map range");
            np->next  = map->head;
            np->start = 0;
            np->end   = rp->start - 1;
            np->data  = data;
            map->head = rp = np;
        }
        if (rp->next) {
            if (rp->end + 1 < rp->next->start) {
                fill = 1;
                start = rp->end + 1;
                end = rp->next->start - 1;
            }
        }
        else if (rp->end != 0xFFFFFFFF) {
            fill = 1;
            start = rp->end + 1;
            end = 0xFFFFFFFF;
        }
        if (fill) {
            np = (struct range *) myalloc(sizeof (struct range), "map range");
            np->next  = rp->next;
            np->start = start;
            np->end   = end;
            np->data  = data;
            rp->next = np;
        }
    }
}

void
delmap(struct map *map, unsigned long data)
{
    struct range *rp, *dp;

    while (map->head && map->head->data == data) {
        dp = map->head;
        map->head = map->head->next;
        free(dp);
    }
    for (rp = map->head; rp->next; rp = rp->next) {
        if (rp->next->data == data) {
            dp = rp->next;
            rp->next = rp->next->next;
            free(dp);
        }
    }
}


/* instruction decoding */

void
mkdecode(const OPCODE *out[], const OPCODE *in)
{
    const OPCODE *op;
    char *r;
    unsigned int i, n;

    for (op = in; op->name; ++op) {
        n = ~op->mask & 0xFFFF;
        for (i = 0; i <= n; ++i)
            out[op->encoding | i] = op;
    }
}


/* input */

int
seekto(ADDR start)
{
    RANGE *frp;
    unsigned long pos;
    int c;

    for (frp = filemap.head; frp; frp = frp->next) {
        if (start >= frp->start && start <= frp->end) {
            pos = frp->data + start - frp->start;
            if (fseek(infp, pos, SEEK_SET)) {
                error("cannot seek to 0x%08lX (PC 0x%08lx): %s",
                      pos, start, strerror(errno));
                return 1;
            }
            /* check whether we're past EOF; stupid fseek() doesn't */
            if ((c = getc(infp)) < 0) {
                error("0x%08lX (PC 0x%08lx) is beyond end of file",
                      pos, start);
                return 1;
            }
            ungetc(c, infp);
            return 0;
        }
    }
    error("0x%08lX is not mapped in the input file", start);
    return 1;
}

int
getword(DIS *dp)
{
    int a, b;

    a = getc(infp);
    b = getc(infp);
    if (a < 0 || b < 0) {
        if (feof(infp))
            return -1;
        return -(errno + 1);
    }
    dp->data[dp->n++] = opt_little? (b << 8) | a : (a << 8) | b;
    return 0;
}


/* disassembly */

int
disop(DISTATE *sp, DIS *dp)
{
    char opndbuf[OPND_MAX], commbuf[OPND_MAX], *opnd, *opndstart;
#define OPNDLEN (OPND_MAX - (opnd - opndstart))
    const char *s;
    WORD inst, tmp, tmq;
    REG r;
    int err, first, i, w, c, delay;
    unsigned short dflags;

    opndbuf[0] = 0;
    commbuf[0] = 0;
    opnd = opndstart = opndbuf;
    inst = dp->data[0];

    dp->flags = sp->flags;
    sp->flags = 0;

    switch (dp->opcode->type) {
    case TYPE_A:
        dp->i = 0xF & inst;
        dp->j = 0xF & (inst >> 4);
        break;
    case TYPE_B:
        dp->i = 0xF & inst;
        dp->x = 0xFF & (inst >> 4);
        dp->w = 8;
        break;
    case TYPE_C:
        dp->i = 0xF & inst;
        dp->x = 0xF & (inst >> 4);
        dp->w = 4;
        break;
    case TYPE_D:
        dp->x = 0xFF & inst;
        dp->w = 8;
        break;
    case TYPE_E:
        dp->i = 0xF & inst;
        break;
    case TYPE_F:
        dp->x = 0x7FF & inst;
        dp->w = 11;
        break;
    case TYPE_Z:
        dp->j = 0xF & (inst >> 4);
        break;
    case TYPE_W:
        dp->x = inst;
        dp->w = 16;
        break;
    }

    for (s = dp->opcode->format; *s; ++s) switch (*s) {
    case '#':
        opnd += snprintf(opnd, OPNDLEN, "%s", fmt.imm);
        break;
    case '&':
        opnd += snprintf(opnd, OPNDLEN, "%s", fmt.and);
        break;
    case '(':
        opnd += snprintf(opnd, OPNDLEN, "%s", fmt.par);
        break;
    case ')':
        opnd += snprintf(opnd, OPNDLEN, "%s", fmt.ens);
        break;
    case '+':
        opnd += snprintf(opnd, OPNDLEN, "%s", fmt.inc);
        break;
    case ',':
        opnd += snprintf(opnd, OPNDLEN, "%s", fmt.nxt);
        break;
    case '-':
        opnd += snprintf(opnd, OPNDLEN, "%s", fmt.dec);
        break;
    case ';':
        opnd = opndstart = commbuf;
        break;
    case '@':
        opnd += snprintf(opnd, OPNDLEN, "%s", fmt.mem);
        break;
    case '2':
        dp->x <<= 1;
        dp->w += 1;
        break;
    case '4':
        dp->x <<= 2;
        dp->w += 2;
        break;
    case 'A':
        opnd += snprintf(opnd, OPNDLEN, "%s", reg[AC]);
        break;
    case 'C':
        opnd += snprintf(opnd, OPNDLEN, "%s", reg[CCR]);
        break;
    case 'F':
        opnd += snprintf(opnd, OPNDLEN, "%s", reg[FP]);
        break;
    case 'J':
        if (ISVALID(sp, dp->j)) {
            dp->x = sp->reg[dp->j];
            dp->w = 32;
        }
        else {
            dp->x = 0;
            dp->w = 0;
        }
        break;
    case 'I':
        if (ISVALID(sp, dp->i)) {
            dp->x = sp->reg[dp->i];
            dp->w = 32;
        }
        else {
            dp->x = 0;
            dp->w = 0;
        }
        break;
    case 'M':
        opnd += snprintf(opnd, OPNDLEN, "%s", reg[ILM]);
        break;
    case 'P':
        opnd += snprintf(opnd, OPNDLEN, "%s", reg[PS]);
        break;
    case 'S':
        opnd += snprintf(opnd, OPNDLEN, "%s", reg[SP]);
        break;
    case 'X':
        /* constant extension word */
        if ((err = getword(dp)) != 0)
            return err;
        dp->x = (dp->x << 16) | dp->data[dp->n - 1];
        dp->w += 16;
        break;
    case 'Y':
        /* coprocessor extension word */
        if ((err = getword(dp)) != 0)
            return err;
        tmp = dp->data[dp->n - 1];
        dp->x = dp->i;
        dp->w = 4;
        dp->c = 0xFF & (tmp >> 8);
        dp->j = 0x0F & (tmp >> 4);
        dp->i = 0x0F & (tmp);
        break;
    case 'a':
        w = dp->w; 
        while (w >= 8) {
            w -= 8;
            opnd += snprintf(opnd, OPNDLEN, "%c", asc(dp->x >> w));
        }
        break;
    case 'b':
        /* shift2 */
        dp->x += 16;
        dp->w += 1;
        break;
    case 'c':
        /* coprocessor operation */
        opnd += snprintf(opnd, OPNDLEN, fmt.u[8], dp->c);
        break;
    case 'd':
        /* unsigned decimal */
        opnd += snprintf(opnd, OPNDLEN, fmt.ud, dp->x);
        break;
    case 'f':
        w = dp->w >> 1;
        tmp = ((1ul<<w)-1) & (dp->x >> w);
        tmq = ((1ul<<w)-1) & dp->x;
        if (tmq)
            opnd += snprintf(opnd, OPNDLEN, "%g", ((double)tmp)/((double)tmq));
        else
            opnd += snprintf(opnd, OPNDLEN, "NaN");
        break;
    case 'g':
        dp->i += SPECIALS;
        goto ri;
    case 'h':
        dp->j += SPECIALS;
        goto rj;
    case 'i':
    ri:
        opnd += snprintf(opnd, OPNDLEN, "%s", reg[dp->i]);
        break;
    case 'j':
    rj:
        opnd += snprintf(opnd, OPNDLEN, "%s", reg[dp->j]);
        break;
    case 'k':
        dp->i += COPROCESSOR;
        goto ri;
    case 'l':
        dp->j += COPROCESSOR;
        goto rj;
    case 'n':
        /* negative constant */
        opnd += snprintf(opnd, OPNDLEN, fmt.n[dp->w + 1],
                         ((1ul << (dp->w+1)) - 1) & NEG(dp->w, (1ul << dp->w) | dp->x));
        break;
    case 'p':
        /* pair */
        w = dp->w >> 1;
        opnd += snprintf(opnd, OPNDLEN, fmt.u[w], ((1ul<<w)-1) & (dp->x >> w));
        opnd += snprintf(opnd, OPNDLEN, "%s", fmt.nxt);
        opnd += snprintf(opnd, OPNDLEN, fmt.u[w], ((1ul<<w)-1) & dp->x);
        break;
    case 'q':
        /* rational */
        w = dp->w >> 1;
        opnd += snprintf(opnd, OPNDLEN, fmt.ud, ((1ul<<w)-1) & (dp->x >> w));
        opnd += snprintf(opnd, OPNDLEN, "/");
        opnd += snprintf(opnd, OPNDLEN, fmt.ud, ((1ul<<w)-1) & dp->x);
        break;
    case 'r':
        /* relative */
        dp->x = dp->pc + 2 + SEX(dp->w, dp->x);
        dp->w = 32;
        break;
    case 's':
        /* signed constant */
        if (ISNEG(dp->w, dp->x)) {
            if ((opt_outflag & OF_CSTYLE) && (opnd[-1] == '+'))
                --opnd;
            opnd += snprintf(opnd, OPNDLEN, fmt.n[dp->w], NEG(dp->w, dp->x));
        }
        else {
            opnd += snprintf(opnd, OPNDLEN, fmt.u[dp->w-1], dp->x);
        }
        break;
    case 'u':
        /* unsigned constant */
        opnd += snprintf(opnd, OPNDLEN, fmt.u[dp->w], dp->x);
        break;
    case 'v':
        /* vector */
        opnd += snprintf(opnd, OPNDLEN, fmt.u[8],
                0xFF - (0xFF & ((dp->pc - dp->memrange->start) / 4)));
        break;
    case 'x':
        dp->x |= 0x100;
        break;
    case 'y':
        dp->c += 8;
        /*FALLTHROUGH*/
    case 'z':
        /* register list */
        opnd += snprintf(opnd, OPNDLEN, "%s", fmt.par);
        first = 1;
        for (i = 0; i < 8; ++i) {
            if (dp->x & (1 << i)) {
                if (first)
                    first = 0;
                else
                    opnd += snprintf(opnd, OPNDLEN, ",");
                opnd += snprintf(opnd, OPNDLEN, "%s",
                                 (dp->x&0x100) ? reg[dp->c+7-i] : reg[dp->c+i]);
            }
        }
        opnd += snprintf(opnd, OPNDLEN, "%s", fmt.ens);
        break;
    default:
        opnd += snprintf(opnd, OPNDLEN, "%c", *s);
        break;
    }

    r = NOREG;
    dflags = 0;
    for (s = dp->opcode->action; *s; ++s) switch (*s) {
    case '!':
        /* jump */
        dflags |= DF_FLOW | DF_BREAK | DF_BRANCH;
        break;
    case '?':
        /* branch */
        dflags |= DF_FLOW | DF_BRANCH;
        break;
    case '(':
        /* call */
        dflags |= DF_FLOW | DF_CALL;
        break;
    case ')':
        /* return */
        dflags |= DF_FLOW | DF_BREAK | DF_CALL;
        break;
    case '_':
        /* delay */
        dflags |= DF_DELAY;
        break;
    case 'A':
        r = AC;
        break;
    case 'C':
        r = CCR;
        break;
    case 'F':
        r = FP;
        break;
    case 'P':
        r = PS;
        break;
    case 'S':
        r = SP;
        break;
    case 'i':
        r = dp->i;
        break;
    case 'j':
        r = dp->j;
        break;
    case 'w':
        SETINVALID(sp, r);
        break;
    case 'v':
        if (OKREG(r)) {
            SETVALID(sp, r);
            sp->reg[r] = dp->x;
        }
        break;
    case 'x':
        r = NOREG;
        break;
    default:
        error("bad action '%c'", *s);
        break;
    }
    dp->flags |= dflags & DF_TO_KEEP;
    sp->flags |= dflags & DF_TO_COPY;
    if (dflags & DF_DELAY)
        sp->flags |= dflags & DF_TO_DELAY;
    else
        dp->flags |= dflags & DF_TO_DELAY;

    /*XXX*/
    dp->opnds = opndbuf;
    if (!commbuf[0] && (dp->memrange->data & MD_TYPEMASK) == MEMTYPE_UNKNOWN) {
        opnd = commbuf;
        for (i = 0; i < dp->n; ++i) {
            *opnd++ = asc(dp->data[i] >> 8);
            *opnd++ = asc(dp->data[i]);
        }
        *opnd = 0;
    }
    dp->comment = commbuf[0] ? commbuf : NULL;
    writedis(outfp, dp);


    return dp->n << 1;
}

int
discode(DISTATE *sp)
{
    DIS *dp;
    int n, err;

    dp = newdis(sp->pc, sp->memrange);
    if ((err = getword(dp)) != 0)
        return err;
    if (!(dp->opcode = decode[dp->data[0]]))
        dp->opcode = &opdata[MD_WORD];
    n = disop(sp, dp);
    freedis(dp);
    return n;
}

int
disdata(DISTATE *sp)
{
    const OPCODE *op;
    DIS *dp;
    unsigned long specs;
    int i, n, err, speclen;

    speclen = (sp->memrange->data >> MD_LENGTHBIT) & MD_LENGTHMASK;
    if (speclen == 0)
        speclen = 1;
    else if (speclen > MD_OPMAX)
        speclen = MD_OPMAX;
    specs = sp->memrange->data >> MD_SPECBIT;
    n = 0;
    for (i = 0; i < speclen; ++i) {
        dp = newdis(sp->pc, sp->memrange);
        if ((err = getword(dp)) != 0)
            return err;
        dp->x = dp->data[0];
        dp->w = 16;
        dp->opcode = &opdata[specs & MD_OPMASK];
        n += disop(sp, dp);
        specs >>= MD_OPLEN;
    }
    return n;
}

ADDR
dis(ADDR start, ADDR end, RANGE *drp, RANGE *mrp)
{
    DISTATE state;
    int n, (*disfn)(DISTATE *);
    ADDR pc;

    if (start & 1) {
        error("Odd start address 0x%08lX\n", start);
        start &=~ 1;
    }
    if (!(end & 1))
        ++end;

    switch (mrp->data & MD_TYPEMASK) {
    default:
    case MEMTYPE_NONE:
        return end + 1;
    case MEMTYPE_UNKNOWN:
    case MEMTYPE_CODE:
        disfn = discode;
        break;
    case MEMTYPE_DATA:
        disfn = disdata;
        break;
    }

    if (seekto(start)) {
        return end + 1;
    }

    state.flags     = 0;
    state.pc        = start;
    state.memrange  = mrp;
    state.rvalid    = 0;

    while (state.pc < end) {
        if ((n = disfn(&state)) < 0) {
            if (n != -1)
                error("input error: %s\n", strerror(-n-1));
            drp->end = state.pc;
            state.pc = ~0;
            break;
        }
        state.pc += n;
    }
    return state.pc;
}

int
process(void)
{
    char rbuf[LINE_MAX], fbuf[LINE_MAX], mbuf[LINE_MAX];
    unsigned long lasttype;
    struct range *r[3];
    ADDR start, end, lastend;
    int i, change;

    r[0] = rangemap.head;
    r[1] = filemap.head;
    r[2] = memmap.head;
    start = lastend = 0;
    lasttype = MEMTYPE_UNKNOWN;
    for(;;) {
        do {
            change = 0;
            for (i = 0; i < 3; ++i) {
                while (r[i] && r[i]->end < start) {
                    change = 1;
                    r[i] = r[i]->next;
                }
                if (!r[i])
                    goto done;
            }
            for (i = 0; i < 3; ++i) {
                if (start < r[i]->start) {
                    change = 1;
                    start = r[i]->start;
                }
            }
        } while (change);
        end = r[0]->end;
        for (i = 1; i < 3; ++i) {
            if (end > r[i]->end) {
                end = r[i]->end;
            }
        }
        if (((lasttype & MD_TYPEMASK) != (r[2]->data & MD_TYPEMASK))
         || (start > lastend + 16)) {
            lasttype = r[2]->data & MD_TYPEMASK;
            if (openoutput(start, 1, "asm"))
                header();
        }
        info("Disassemble 0x%08lX-0x%08lX (file 0x%08lX) as %s",
             start, end, r[1]->data+start-r[1]->start, memmapname(r[2]->data));
        nl();
        start = lastend = dis(start, end, r[0], r[2]);
        if (lastend < end)
            break;
        nl();
    }
done:
    fclose(infp);
    fclose(outfp);
    return 0;
}


/* initialization */

void
initialize(void)
{
    char *s, fmtbuf[FILENAME_MAX];
    int n, w;
    time_t now;

    if (opt_outflag & (OF_VERBOSE|OF_DEBUG))
        fprintf(stderr, "DFR %s\n", version);

    time(&now);
    strcpy(fmtbuf, ctime(&now));
    if ((s = strchr(fmtbuf, '\n')) != NULL)
        *s = 0;
    starttime = savestr(fmtbuf);

    if (!opt_infile) {
        fprintf(stderr, "%s: no input file\n", cmdname);
        usage();
        exit(1);
    }
    if (!strcmp(opt_infile, "-")) {
        opt_infile = "<stdin>";
        infp = stdin;
        if (!opt_outfile)
            opt_outfile = "-";
    }
    else if (!(infp = fopen(opt_infile, "r"))) {
        fprintf(stderr, "%s: cannot open input file \"%s\": %s\n",
            cmdname, opt_infile, strerror(errno));
        exit(1);
    }

    /* opcode decoding */
    mkdecode(decode, opcode);
    if (opt_outflag & OF_ALTSTACK)
        mkdecode(decode, opaltstack);
    if (opt_outflag & OF_ALTSHIFT)
        mkdecode(decode, opaltshift);
    if (opt_outflag & OF_ALTDMOV)
        mkdecode(decode, opaltdmov);
    if (opt_outflag & OF_ALTSPECIALS)
        mkdecode(decode, opaltspecial);

    /* format strings */
    fmt.u[0] = fmt.n[0] = "";
    for (n = 1; n <= BITS; ++n) {
        w = 1 + (n - 1) / 4;
        snprintf(fmtbuf, 16,
                 opt_outflag & OF_HEXDOLLAR ? "-$%%0%uX" : "-0x%%0%uX", w);
        fmt.u[n] = savestr(fmtbuf + 1);
        fmt.n[n] = savestr(fmtbuf);
    }
    if (opt_outflag & OF_CSTYLE) {
        fmt.imm = "";
        fmt.and = "+";
        fmt.inc = "++";
        fmt.dec = "--";
        fmt.mem = "*";
    }
    if (opt_outflag & OF_ALTREG) {
        reg[AC] = "AC";
        reg[FP] = "FP";
        reg[SP] = "SP";
    }

    if (opt_outflag & (OF_FILEMAP|OF_MEMORYMAP))
        if (openoutput(0, 0, opt_split ? "map" : "asm"))
            header();

    fixmap(&filemap, 0);
    if (opt_outflag & OF_FILEMAP)
        dumpmap(&filemap);

    fixmap(&memmap, MEMTYPE_UNKNOWN);
    fillmap(&memmap, MEMTYPE_UNKNOWN);
    delmap(&memmap, MEMTYPE_NONE);
    if (opt_outflag & OF_MEMORYMAP)
        dumpmap(&memmap);

    fixmap(&rangemap, 1);
    if (opt_outflag & (OF_FILEMAP|OF_MEMORYMAP))
        dumpmap(&rangemap);
}

void
finalize(void)
{
    fclose(infp);
    fclose(outfp);
}


/* options */

void
showhelp(const char **msgs)
{
    const char *a, *b, *fmt;

    for(;;) {
        a = *msgs++;
        b = *msgs++;
        if (a) {
            if (b) {
                fmt = "  %-18s-- %s\n";
            }
            else {
                fmt = "%s\n";
            }
        }
        else {
            a = "";
            if (b) {
                fmt = "  %-18s   %s\n";
            }
            else {
                break;
            }
        }
        fprintf(stderr, fmt, a, b);
    }
}

void
usage(void)
{
    const char *help[] = {
        "-d range",         "disassemble only specified range",
     /* "-e address=name",  "define entry point symbol", */
        "-f range=address", "map range of input file to memory address",
        "-h",               "display this message",
        "-i range=offset",  "map range of memory to input file offset",
        "-l",               "little-endian input file",
        "-m range=type",    "describe memory range (use -m? to list types)",
        "-o filename",      "output file",
        "-r",               "separate output file for each memory range",
     /* "-s address=name",  "define symbol", */
        "-t address",       "equivalent to -m address,0x400=DATA:V",
        "-v",               "verbose",
        "-w options",       "output options (use -w? to list options)",
        "-x file",          "read options from file",
        "Numbers are C-style. A range is start-end or start,length.", NULL,
        NULL,               NULL
    };
    fprintf(stderr, "Usage: %s [options] filename\n", cmdname);
    fprintf(stderr, "Options:\n");
    showhelp(help);
}

unsigned long
parseul(const char *s, const char **rp)
{
    unsigned long v;
    char *p;

    v = strtoul(s, &p, 0);
    if ((p != s) && (*p != 0)) {
        switch (tolower(*p)) {
        case 'k': ++p; v *=    1024; break;
        case 'm': ++p; v *= 1048576; break;
        }
    }
    if (rp)
        *rp = p;
    return v;
}

int
parserange(int opt, const char *s, const char **rp,
           unsigned long *startp, unsigned long *endp)
{
    unsigned long v;
    int c;

    v = parseul(s, rp);
    if (*rp == s) {
        fprintf(stderr, "%s: -%c expected a number at \"%s\"\n",
                cmdname, opt, s);
        return 1;
    }
    *startp = v;
    *endp = 0xFFFFFFFF;
    if (((c = **rp) == ',') || (c == '-')) {
        s = *rp + 1;
        v = parseul(s, rp);
        if (*rp == s) {
            *rp = (char *)s - 1;
            fprintf(stderr, "%s: -%c expected a number at \"%s\"\n",
                    cmdname, opt, s);
            return 1;
        }
        if (c == '-')
            *endp = v;
        else
            *endp = *startp + v - 1;
    }
    if (*endp < *startp) {
        fprintf(stderr, "%s: -%c range has end less than start 0x%08lX\n",
            cmdname, opt, *startp);
        return 1;
    }
    return 0;
}

int
parsemap(int opt, const char *s, const char **rp,
         unsigned long *startp, unsigned long *endp, unsigned long *mapp)
{
    unsigned long v;
    int r;

    if ((r = parserange(opt, s, rp, startp, endp)) != 0)
        return r;
    s = *rp;
    if (*s == ':' || *s == '=') {
        ++s;
        v = parseul(s, rp);
        if (*rp == s) {
            *rp = s - 1;
            fprintf(stderr, "%s: -%c expected a number at \"%s\"\n",
                    cmdname, opt, *rp);
            return 1;
        }
        *mapp = v;
        return 0;
    }
    fprintf(stderr, "%s: -%c missing map value\n", cmdname, opt);
    return 1;
}

int
parseflags(int opt, const char *arg, uint32_t *flagsp, struct flag *flag)
{
    char *s;
    int i, on;

    while (*arg) {
        if (!strncasecmp(arg, "no", 2)) {
            on = 0;
            arg += 2;
        }
        else {
            on = 1;
        }
        for (i = 0; flag[i].width; ++i) {
            if (!strncasecmp(arg, flag[i].flag, flag[i].width)) {
                if (flag[i].value & OF_INVERT)
                    on = !on;
                if (on)
                    *flagsp |= flag[i].value;
                else
                    *flagsp &= ~flag[i].value;
                break;
            }
        }
        if (!flag[i].width) {
            if (*arg != '?')
                fprintf(stderr, "%s: unknown flag at \"%s\"\n", cmdname, arg);
            for (i = 0; flag[i].width; ++i)
                if (flag[i].desc)
                    fprintf(stderr, "  -%c %-15s-- %s\n",
                            opt, flag[i].flag, flag[i].desc);
            return 1;
        }
        if ((s = strchr(arg, ',')) != NULL)
            arg = s + 1;
        else
            break;
    }
    return 0;
}
const char *memtypehelp[] = {
    "Memtypes are:",    NULL,
    "NONE",             "do not disassemble",
    "UNKNOWN",          "unknown contents",
    "CODE",             "disassemble as code where possible",
    "DATA[:spec]",      "disassemble as data; spec is up to 8 of:",
    NULL,               "  L -- long (32-bit) data",
    NULL,               "  N -- long (32-bit) data, no labels",
    NULL,               "  R -- rational",
    NULL,               "  V -- vector",
    NULL,               "  W -- word (16-bit) data",
    NULL,               NULL
};

int
parsememtype(const char *arg, unsigned long *memp)
{
    char c, *s, *wtf;
    unsigned long memtype;
    int speclen, specshift, md;

    memtype = MEMTYPE_UNKNOWN;
    wtf = "memory type";
    if (arg && *arg) switch (tolower(*arg)) {
    case 'c':
        memtype = MEMTYPE_CODE;
        break;
    case 'd':
        wtf = "data type";
        specshift = MD_SPECBIT;
        speclen = 0;
        memtype = MKDATA(1, MD_WORD);
        if ((s = strchr(arg, ':')) != NULL) {
            ++s;
            while ((c = *s++) != 0) {
                if (++speclen > MD_OPMAX)
                    goto usage;
                switch (tolower(c)) {
                case 'l':   md = MD_LONG;       break;
                case 'n':   md = MD_LONGNUM;    break;
                case 'r':   md = MD_RATIONAL;   break;
                case 'v':   md = MD_VECTOR;     break;
                case 'w':   md = MD_WORD;       break;
                default:    goto usage;
                }
                memtype |= md << specshift;
                specshift += MD_OPLEN;
            }
        }
        break;
    case 'n':
        memtype = MEMTYPE_NONE;
        break;
    case 'u':
        memtype = MEMTYPE_UNKNOWN;
        break;
    case 'v':
        memtype = MKDATA(1, MD_VECTOR);
        break;
    default:
    usage:
        fprintf(stderr, "%s: unrecognized %s at \"%s\"\n", cmdname, wtf, arg);
        showhelp(memtypehelp);
        return 1;
    }
    *memp = memtype;
    return 0;
}

/* reinventing the wheel because resetting getopt() isn't portable */

struct parseopt {
    int    index;
    int    argc;
    char **argv;
    char  *cur;
};

void
parseopt_begin(struct parseopt *op, int argc, char *argv[])
{
    op->index = 0;
    op->argc  = argc;
    op->argv  = argv;
    op->cur   = NULL;
}

void
parseopt_end(struct parseopt *op)
{
}

int
parseopt_next(struct parseopt *op)
{
    if (!op->cur || !*op->cur) {
        if (++op->index >= op->argc)
            return -1;
        op->cur = op->argv[op->index];
        if (*op->cur != '-')
            return 0;
        ++op->cur;
    }
    return *op->cur++;
}

const char *
parseopt_arg(struct parseopt *op)
{
    const char *r;

    if (!op->cur || !*op->cur) {
        if (++op->index >= op->argc)
            return NULL;
        op->cur = op->argv[op->index];
    }
    r = op->cur;
    op->cur = NULL;
    return r;
}

void
options(int argc, char *argv[])
{
    struct parseopt pos;
    unsigned long start, end, map;
    int opt;
    const char *arg, *r;

    parseopt_begin(&pos, argc, argv);
    while ((opt = parseopt_next(&pos)) >= 0) switch (opt) {
    case 0:
        if (opt_infile) {
            fprintf(stderr, "%s: too many input files\n", cmdname);
            usage();
            exit(1);
        }
        opt_infile = parseopt_arg(&pos);
        break;
    case 'D': case 'd':
        if (!(arg = parseopt_arg(&pos)))
            goto missing;
        if (parserange(opt, arg, &r, &start, &end))
            break;
        insmap(&rangemap, start, end, 1);
        break;
    case 'E': case 'e':
        if (!(arg = parseopt_arg(&pos)))
            goto missing;
        fprintf(stderr, "%s: symbol table not implemented yet!\n");
        exit(1);
        break;
    case 'F': case 'f':
        if (!(arg = parseopt_arg(&pos)))
            goto missing;
        if (parsemap(opt, arg, &r, &start, &end, &map))
            break;
        insmap(&filemap, map, map + end - start, start);
        break;
    case 'H': case 'h': case '?':
        usage();
        exit(0);
        break;
    case 'I': case 'i':
        if (!(arg = parseopt_arg(&pos)))
            goto missing;
        if (parsemap(opt, arg, &r, &start, &end, &map))
            break;
        insmap(&filemap, start, end, map);
        break;
    case 'L': case 'l':
        opt_little = 1;
        break;
    case 'M': case 'm':
        if (!(arg = parseopt_arg(&pos))
         || parserange(opt, arg, &r, &start, &end)) {
            showhelp(memtypehelp);
            exit(1);
        }
        if (parsememtype(r + 1, &map))
            exit(1);
        insmap(&memmap, start, end, map);
        break;
    case 'O': case 'o':
        if (!(arg = parseopt_arg(&pos)))
            goto missing;
        opt_outfile = arg;
        break;
    case 'R': case 'r':
        opt_split = 1;
        break;
    case 'S': case 's':
        if (!(arg = parseopt_arg(&pos)))
            goto missing;
        fprintf(stderr, "%s: symbol table not implemented yet!\n");
        exit(1);
        break;
    case 'T': case 't':
        if (!(arg = parseopt_arg(&pos)))
            goto missing;
        start = parseul(arg, &r);
        insmap(&memmap, start, start + 0x3FF, MKDATA(1, MD_VECTOR));
        break;
    case 'V': case 'v':
        opt_outflag |= OF_VERBOSE;
        break;
    case 'W': case 'w':
        if (!(arg = parseopt_arg(&pos)))
            goto missing;
        if (parseflags(opt, arg, &opt_outflag, outflags))
            exit(1);
        break;
    case 'X': case 'x':
        if (!(arg = parseopt_arg(&pos)))
            goto missing;
        if (fileoptions(arg)) {
            fprintf(stderr, "%s: cannot open options file \"%s\": %s\n",
                cmdname, arg, strerror(errno));
            exit(1);
        }
        break;
    case 'Z': case 'z':
        opt_outflag |= OF_DEBUG;
        break;
    default:
        fprintf(stderr, "%s: unknown option \"-%c\"\n", cmdname, opt);
        usage();
        exit(1);
    }
    parseopt_end(&pos);
    return;
missing:
    fprintf(stderr, "%s: option \"-%c\" requires an argument\n", cmdname, opt);
}

int
fileoptions(const char *filename)
{
    char *s, *p, buf[LINE_MAX], *argv[4];
    FILE *fp;
    if (!(fp = fopen(filename, "r")))
        return 1;
    while (fgets(buf, LINE_MAX, fp)) {
        if ((s = strrchr(buf, '\n')) != NULL)
            *s = 0;
        for (s = buf; isspace(*s); ++s)
            ;
        if ((*s == 0) || (*s == '#'))
            continue;
        if ((*s == '-') && (s[1] != 0)) {
            if (isspace(s[2])) {
                s[2] = 0;
                for (p = s + 3; *p && isspace(*p); ++p)
                    ;
                if (*p) {
                    argv[0] = cmdname;
                    argv[1] = s;
                    argv[2] = p;
                    argv[3] = 0;
                    options(3, argv);
                    continue;
                }
            }
        }
        argv[0] = cmdname;
        argv[1] = s;
        argv[2] = 0;
        options(2, argv);
    }
    fclose(fp);
    return 0;
}

void
preoptions()
{
    char *home, buf[FILENAME_MAX];

    if ((home = getenv("HOME")) != NULL) {
        snprintf(buf, FILENAME_MAX, "%s/.dfrrc", home);
        (void) fileoptions(buf);
        snprintf(buf, FILENAME_MAX, "%s/dfr.txt", home);
        (void) fileoptions(buf);
    }
    (void) fileoptions(".dfrrc");
    (void) fileoptions("dfr.txt");
}

int
main(int argc, char *argv[])
{
    if (argv[0]) {
        if (!(cmdname = strrchr(argv[0], '/')))
            cmdname = argv[0];
        else
            ++cmdname;
    }
    preoptions();
    options(argc, argv);
    initialize();
    process();
    finalize();
    exit(0);
}

