/*
 *----------------------------------------------------------------------
 *    SOFTUNE micro T-REALOS/FR
 *
 *    Copyright (C) FUJITSU LIMITED 2006-2007 All rights reserved.
 *    This product uses the Source Code of micro T-Kernel under the micro 
 *    T-License granted by the T-Engine forum (http://www.t-engine.org). 
 *                                             Last update : 2007/03/26
 *----------------------------------------------------------------------
 */

/*
 * Memory stamp
 */
void knl_mem_stamp(void)
{
	char unl_stamp[] = "Copyright (C) 2006-2007 by Ken Sakamura. All rights reserved.";
	char fj_stamp[] = "Copyright (C) FUJITSU LIMITED 2006-2007 All rights reserved.";
}
