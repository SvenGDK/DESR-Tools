/*
 *----------------------------------------------------------------------
 *    micro T-Kernel
 *
 *    Copyright (C) 2006-2007 by Ken Sakamura. All rights reserved.
 *    micro T-Kernel is distributed under the micro T-License.
 *----------------------------------------------------------------------
 *
 *    Version:   1.00.00
 *    Released by T-Engine Forum(http://www.t-engine.org) at 2007/03/26.
 *
 *----------------------------------------------------------------------
 */

/*
 *	@(#)tkernel.h
 *
 *	T-Kernel Definition
 */

#ifndef __TK_TKERNEL_H__
#define __TK_TKERNEL_H__

#include <basic.h>
#include <tk/typedef.h>
#include <tk/errno.h>

#include <tk/syscall.h>
#include <tk/syslib.h>

#endif /* __TK_TKERNEL_H__ */
