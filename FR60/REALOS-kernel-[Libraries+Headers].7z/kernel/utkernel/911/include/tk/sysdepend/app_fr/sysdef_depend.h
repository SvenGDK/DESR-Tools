/*
 *----------------------------------------------------------------------
 *    micro T-Kernel
 *
 *    Copyright (C) 2006-2007 by Ken Sakamura. All rights reserved.
 *    micro T-Kernel is distributed under the micro T-License.
 *----------------------------------------------------------------------
 *    SOFTUNE micro T-REALOS/FR
 *
 *    Copyright (C) FUJITSU LIMITED 2006-2007 All rights reserved.
 *    This product uses the Source Code of micro T-Kernel under the micro 
 *    T-License granted by the T-Engine forum (http://www.t-engine.org). 
 *                                             Last update : 2007/03/26
 *----------------------------------------------------------------------
 *
 *    Version:   1.00.00
 *    Released by T-Engine Forum(http://www.t-engine.org) at 2007/03/26.
 *
 *----------------------------------------------------------------------
 */

/*
 *	@(#)sysdef_depend.h (tk/FR)
 *
 *	Definition about FR
 *
 *	Included also from assembler program.
 */

#ifndef __TK_SYSDEF_DEPEND_H__
#define __TK_SYSDEF_DEPEND_H__

/*
 * Interrupt Level Mask (ILM) Data Define
 */
#define	ILM_16	16
#define	ILM_17	17
#define	ILM_18	18
#define	ILM_19	19
#define	ILM_20	20
#define	ILM_21	21
#define	ILM_22	22
#define	ILM_23	23
#define	ILM_24	24
#define	ILM_25	25
#define	ILM_26	26
#define	ILM_27	27
#define	ILM_28	28
#define	ILM_29	29
#define	ILM_30	30
#define	ILM_31	31

/*
 * Condition Code (CCR) Define
 */
#define	CCR_C	0x01
#define	CCR_V	0x02
#define	CCR_Z	0x04
#define	CCR_N	0x08
#define	CCR_I	0x10
#define	CCR_S	0x20

#define	CCR_C_NOT	0xfe
#define	CCR_V_NOT	0xfd
#define	CCR_Z_NOT	0xfb
#define	CCR_N_NOT	0xf7
#define	CCR_I_NOT	0xef
#define	CCR_S_NOT	0xdf

/*
 * Interrupt Factor Number
 */
#define INT_ICR00	0x10	/* ext.int 0				*/
#define INT_ICR01	0x11	/* ext.int 1				*/
#define INT_ICR02	0x12	/* ext.int 2				*/
#define INT_ICR03	0x13	/* ext.int 3				*/
#define INT_ICR04	0x14	/* UART 0 Receive	       		*/
#define INT_ICR05	0x15	/* UART 1 Receive      			*/
#define INT_ICR06	0x16	/* UART 2 Receive      			*/
#define INT_ICR07	0x17	/* UART 0 Send				*/
#define INT_ICR08	0x18	/* UART 1 Send				*/
#define INT_ICR09	0x19	/* UART 2 Send				*/
#define INT_ICR10	0x1a	/* DMAC 0 End/Error	       		*/
#define INT_ICR11	0x1b	/* DMAC 1 End/Error			*/
#define INT_ICR12	0x1c	/* DMAC 2 End/Error			*/
#define INT_ICR13	0x1d	/* DMAC 3 End/Error			*/
#define INT_ICR14	0x1e	/* DMAC 4 End/Error			*/
#define INT_ICR15	0x1f	/* DMAC 5 End/Error			*/
#define INT_ICR16	0x20	/* DMAC 6 End/Error    			*/
#define INT_ICR17	0x21	/* DMAC 7 End/Error			*/
#define INT_ICR18	0x22	/* A/D					*/
#define INT_ICR19	0x23	/* Reload Timer 0			*/
#define INT_ICR20	0x24	/* Reload Timer 1			*/
#define INT_ICR21	0x25	/* Reload Timer 2			*/
#define INT_ICR22	0x26	/* PWM 0				*/
#define INT_ICR23	0x27	/* PWM 1				*/
#define INT_ICR24	0x28	/* PWM 2				*/
#define INT_ICR25	0x29	/* PWM 3				*/
#define INT_ICR26	0x2a	/* U-TIMER 0				*/
#define INT_ICR27	0x2b	/* U-TIMER 1				*/
#define INT_ICR28	0x2c	/* U-TIMER 2				*/
#define INT_ICR29	0x2d	/* system reserve			*/
#define INT_ICR30	0x2e	/* system reserve	      		*/
#define INT_ICR31	0x2f	/* system reserve	       		*/
#define INT_ICR32	0x30	/* system reserve	       		*/
#define INT_ICR33	0x31	/* system reserve      			*/
#define INT_ICR34	0x32	/* system reserve			*/
#define INT_ICR35	0x33	/* system reserve			*/
#define INT_ICR36	0x34	/* system reserve			*/
#define INT_ICR37	0x35	/* system reserve			*/
#define INT_ICR38	0x36	/* system reserve			*/
#define INT_ICR39	0x37	/* system reserve			*/
#define INT_ICR40	0x38	/* system reserve			*/
#define INT_ICR41	0x39	/* system reserve      			*/
#define INT_ICR42	0x3a	/* system reserve      			*/
#define INT_ICR43	0x3b	/* system reserve	       		*/
#define INT_ICR44	0x3c	/* system reserve      			*/
#define INT_ICR45	0x3d	/* system reserve		       	*/
#define INT_ICR46	0x3e	/* system reserve			*/
#define INT_ICR47	0x3f	/* Dlayed Interrupt			*/

#define	INT_DI		INT_ICR47	/* Dlayed Interrupt No.		*/
#define INT_SVC		0x40	/* System Call Tarp No.			*/
#define INT_MONITOR	0x41	/* Monitor Call Tarp No.		*/
#define INT_DBG		0x42	/* Debugger Support Tarp No.	*/

#endif /* __TK_SYSDEF_DEPEND_H__ */
