/*
 *----------------------------------------------------------------------
 *    micro T-Kernel
 *
 *    Copyright (C) 2006-2007 by Ken Sakamura. All rights reserved.
 *    micro T-Kernel is distributed under the micro T-License.
 *----------------------------------------------------------------------
 *    SOFTUNE micro T-REALOS/FR
 *
 *    Copyright (C) FUJITSU LIMITED 2006-2007 All rights reserved.
 *    This product uses the Source Code of micro T-Kernel under the micro 
 *    T-License granted by the T-Engine forum (http://www.t-engine.org). 
 *                                             Last update : 2007/03/26
 *----------------------------------------------------------------------
 *
 *    Version:   1.00.00
 *    Released by T-Engine Forum(http://www.t-engine.org) at 2007/03/26.
 *
 *----------------------------------------------------------------------
 */

/*
 *	@(#)sysdef_common.h (tk)
 *
 *	System dependencies definition.
 *	Included also from assembler program.
 */

#ifndef __TK_SYSDEF_COMMON_H__
#define __TK_SYSDEF_COMMON_H__

#  include <tk/sysdepend/app_fr/sysdef_depend.h>

#endif /* __TK_SYSDEF_COMMON_H__ */
