/*
 *----------------------------------------------------------------------
 *    micro T-Kernel
 *
 *    Copyright (C) 2006-2007 by Ken Sakamura. All rights reserved.
 *    micro T-Kernel is distributed under the micro T-License.
 *----------------------------------------------------------------------
 *    SOFTUNE micro T-REALOS/FR
 *
 *    Copyright (C) FUJITSU LIMITED 2006-2007 All rights reserved.
 *    This product uses the Source Code of micro T-Kernel under the micro 
 *    T-License granted by the T-Engine forum (http://www.t-engine.org). 
 *                                             Last update : 2007/03/26
 *----------------------------------------------------------------------
 *
 *    Version:   1.00.00
 *    Released by T-Engine Forum(http://www.t-engine.org) at 2007/03/26.
 *
 *----------------------------------------------------------------------
 */

/*
 *	@(#)cpudef.h (tk/FR)
 *
 *	FR dependent definition
 */

#ifndef __TK_CPUDEF_H__
#define __TK_CPUDEF_H__

#ifdef __cplusplus
extern "C" {
#endif

/*
 * General purpose register		tk_get_reg tk_set_reg
 */
typedef struct t_regs {
	VP	pc;
	UW	ps;
	VP	rp;
	VW	mdl;
	VW	mdh;
	VW	r[15];
/*	VW	r15; */
} T_REGS;

/*
 * Exception-related register		tk_get_reg tk_set_reg
 */
typedef struct t_eit {
	VP	pc;
	UW	ps;
} T_EIT;

/*
 * Control register			tk_get_reg tk_set_reg
 */

typedef struct t_cregs {
	VP	usp;	/* User stack pointer */
} T_CREGS;

/*
 * Coprocessor register			tk_get_cpr tk_set_cpr
 */

typedef union {
	INT	dummy;	/* It is not able to define the UNION-type using fcc911s. */
#if 0
	T_COP0REGS	cop0;
	T_COP1REGS	cop1;
	T_COP2REGS	cop2;
	T_COP3REGS	cop3;
#endif
} T_COPREGS;

#ifdef __cplusplus
}
#endif
#endif /* __TK_CPUDEF_H__ */
