/*
 *----------------------------------------------------------------------
 *    micro T-Kernel
 *
 *    Copyright (C) 2006-2007 by Ken Sakamura. All rights reserved.
 *    micro T-Kernel is distributed under the micro T-License.
 *----------------------------------------------------------------------
 *    SOFTUNE micro T-REALOS/FR
 *
 *    Copyright (C) FUJITSU LIMITED 2006-2007 All rights reserved.
 *    This product uses the Source Code of micro T-Kernel under the micro 
 *    T-License granted by the T-Engine forum (http://www.t-engine.org). 
 *                                             Last update : 2007/03/26
 *----------------------------------------------------------------------
 *
 *    Version:   1.00.00
 *    Released by T-Engine Forum(http://www.t-engine.org) at 2007/03/26.
 *
 *----------------------------------------------------------------------
 */

/*
 *	@(#)syslib_depend.h (tk/FR)
 *
 *	micro T-Kernel FR Library
 */

#ifndef __TK_SYSLIB_DEPEND_H__
#define __TK_SYSLIB_DEPEND_H__

#include <tk/errno.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * CPU interrupt control
 *	'intsts' is the value of PS register in CPU
 *	disint()  Set PS.I = 0 and return the original PS to the return value.
 *	enaint()  Set PS.I = intsts.I. Do not change except for PS.I.
 *		  Return the original PS to the return value.
 */
IMPORT UINT disint( void );
IMPORT UINT enaint( UINT intsts );
#define	DI(intsts)	( (intsts) = disint() )
#define	EI(intsts)	( enaint(intsts) )
#define	isDI(intsts)	( ((intsts) & 0x0010U) == 0 )

/*
 * Interrupt vector
 *	Interrupt vector is the value of the interrupt factor code INTVEC 2
 */
typedef UINT	INTVEC;

#define	DINTNO(intvec)	(intvec)	/* Convert to the interrupt definition number */

/*
 * Interrupt vector value (part)
 */

/*
 * Interrupt controller control
 */

/*
 * Interrupt enable
 *	Enable the interrupt specified by 'intvec.'
 */
IMPORT void EnableInt( INTVEC intvec, INT level );

/*
 * Interrupt disable
 *	Disable the interrupt specified by 'intvec.'
 */
IMPORT void DisableInt( INTVEC intvec );

/*
 * Clear interrupt request
 *	Clear the interrupt request specified by 'intvec.'
 *	Available only for edge trigger.
 *	For edge trigger, need to clear the interrupt with interrupt handler.
 */
IMPORT void ClearInt( INTVEC intvec );

/*
 * Check for existence of interrupt request
 *	Check whether there is an interrupt request specified by 'intvec.'
 *	If there is an interrupt request, return TRUE (except 0).
 */
IMPORT BOOL CheckInt( INTVEC intvec );

/*
 * Issue EOI(End Of Interrupt)
 */
#define	EndOfInt(intvec)

/* ------------------------------------------------------------------------ */

/*
 * I/O port access
 *	Only memory mapped I/O for SH
 */
Inline void out_w( INT port, UW data )
{
/*	Asm("st %0, @%1":: "r"(data), "r"(port)); */
	*(UW *)port = data;
}
Inline void out_h( INT port, UH data )
{
/*	Asm("sth %0, @%1":: "r"(data), "r"(port)); */
	*(UH *)port = data;
}
Inline void out_b( INT port, UB data )
{
/*	Asm("stb %0, @%1":: "r"(data), "r"(port)); */
	*(UB *)port = data;
}

Inline UW in_w( INT port )
{
	UW	data;
/*	Asm("ld @%1, %0": "=r"(data): "r"(port)); */
	data = *(UW *)port;
	return data;
}
Inline UH in_h( INT port )
{
	UH	data;
/*	Asm("lduh @%1, %0": "=r"(data): "r"(port)); */
	data = *(UH *)port;
	return data;
}
Inline UB in_b( INT port )
{
	UB	data;
/*	Asm("ldub @%1, %0": "=r"(data): "r"(port)); */
	data = *(UB *)port;
	return data;
}

#ifdef __cplusplus
}
#endif
#endif /* __TK_SYSLIB_DEPEND_H__ */
