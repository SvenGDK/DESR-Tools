/*
 *----------------------------------------------------------------------
 *    micro T-Kernel
 *
 *    Copyright (C) 2006-2007 by Ken Sakamura. All rights reserved.
 *    micro T-Kernel is distributed under the micro T-License.
 *----------------------------------------------------------------------
 *    SOFTUNE micro T-REALOS/FR
 *
 *    Copyright (C) FUJITSU LIMITED 2006-2007 All rights reserved.
 *    This product uses the Source Code of micro T-Kernel under the micro 
 *    T-License granted by the T-Engine forum (http://www.t-engine.org). 
 *                                             Last update : 2007/03/26
 *----------------------------------------------------------------------
 *
 *    Version:   1.00.00
 *    Released by T-Engine Forum(http://www.t-engine.org) at 2007/03/26.
 *
 *----------------------------------------------------------------------
 */

/*
 *	@(#)tmonitor.h (tm)
 *
 *	T-Monitor equivalent function
 */

#ifndef __TM_TMONITOR_H__
#define __TM_TMONITOR_H__

#include <basic.h>

#ifdef __cplusplus
extern "C" {
#endif


/*
 * Monitor service function
 */
#if 0

IMPORT void tm_monitor( void );
IMPORT INT  tm_getchar( INT wait );
IMPORT INT  tm_putchar( INT c );
IMPORT INT  tm_getline( UB *buff );
IMPORT INT  tm_putstring( const UB *buff );
IMPORT INT  tm_command( const UB *buff );
IMPORT void tm_exit( INT mode );

#else

#define _tm_monitor()    {}
#define _tm_getchar(a)   {}
#define _tm_putchar(a)   {*((char*)0x61)=(char)a;}

static void _tm_putstring(const char *s)
{
	const char* p = s;
	while(*p != '\0'){
		_tm_putchar(*p);
		p++;
	}
}

#define tm_monitor   _tm_monitor
#define tm_getchar   _tm_getchar
#define tm_putchar   _tm_putchar
#define tm_putstring _tm_putstring
#define tm_exit(a)    {}

#endif

#ifdef __cplusplus
}
#endif
#endif /* __TM_TMONITOR_H__ */
