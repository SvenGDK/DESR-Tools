/*
 *----------------------------------------------------------------------
 *    micro T-Kernel
 *
 *    Copyright (C) 2006-2007 by Ken Sakamura. All rights reserved.
 *    micro T-Kernel is distributed under the micro T-License.
 *----------------------------------------------------------------------
 *    SOFTUNE micro T-REALOS/FR
 *
 *    Copyright (C) FUJITSU LIMITED 2006-2007 All rights reserved.
 *    This product uses the Source Code of micro T-Kernel under the micro 
 *    T-License granted by the T-Engine forum (http://www.t-engine.org). 
 *                                             Last update : 2007/03/26
 *----------------------------------------------------------------------
 *
 *    Version:   1.00.00
 *    Released by T-Engine Forum(http://www.t-engine.org) at 2007/03/26.
 *
 *----------------------------------------------------------------------
 */

/*
 *	cpu_insn.h (FR)
 *	FR-Dependent Operation
 */

#ifndef _CPU_INSN_
#define _CPU_INSN_

#include <sys/sysinfo.h>
#include "offset.h"

/* ------------------------------------------------------------------------ */
/*
 *	Control register operation
 */

#if USE_TRAP
/*
 * Get PSR
 */
Inline UINT knl_getPS( void )
{
	IMPORT	UW	*knl_scctx_fp;			/* FP of System Call Register Context */
	return (*(UW*)((char*)knl_scctx_fp+SCSF_PS));	/* Load ps on SC Stack Frame */
}
#else

IMPORT UINT knl_getPS( void );

#endif

/* ------------------------------------------------------------------------ */
/*
 *	EIT-related
 */

/*
 * Set interrupt handler
 */
Inline void knl_define_inthdr( INT vecno, FP inthdr )
{
	if(knl_intvec) knl_intvec[ (N_INTVEC -1) - vecno ] = inthdr;
}

/*
 * If it is the task-independent part, TRUE
 *	If EIT stack is consumed, the task independent part
 */
Inline BOOL knl_isTaskIndependent( void )
{
	return ( (knl_getPS() & 0x20 ) == 0 )? TRUE: FALSE;
}

/*
 * Move to/Restore task independent part
 */
Inline void knl_EnterTaskIndependent( void )
{
}
Inline void knl_LeaveTaskIndependent( void )
{
}

#endif
