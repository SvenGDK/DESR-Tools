/*
 *----------------------------------------------------------------------
 *    micro T-Kernel
 *
 *    Copyright (C) 2006-2007 by Ken Sakamura. All rights reserved.
 *    micro T-Kernel is distributed under the micro T-License.
 *----------------------------------------------------------------------
 *    SOFTUNE micro T-REALOS/FR
 *
 *    Copyright (C) FUJITSU LIMITED 2006-2007 All rights reserved.
 *    This product uses the Source Code of micro T-Kernel under the micro 
 *    T-License granted by the T-Engine forum (http://www.t-engine.org). 
 *                                             Last update : 2007/03/26
 *----------------------------------------------------------------------
 *
 *    Version:   1.00.00
 *    Released by T-Engine Forum(http://www.t-engine.org) at 2007/03/26.
 *
 *----------------------------------------------------------------------
 */

/*
 *	cpu_task.h (FR)
 *	CPU-Dependant Task Start Processing
 */

#ifndef _CPU_TASK_
#define _CPU_TASK_

/*
 * System stack configuration at task startup
 */
typedef struct {
	VP	pc;
	UW	ps;
	VP	rp;
	VW	mdl;
	VW	mdh;
	VW	r[15];
} SStackFrame;

/*
 * Size of system stack area destroyed by 'make_dormant()'
 * In other words, the size of area required to write by 'setup_context().'
 */
#define	DORMANT_STACK_SIZE	( sizeof(VW) * 4 )	/* To 'ps' position */

/*
 * Initial value for task startup
 */
#define	INIT_PS	( (ILM_31<<16) | CCR_S | CCR_I )

/*
 * Create stack frame for task startup
 *	Call from 'make_dormant()'
 */
Inline void knl_setup_context( TCB *tcb )
{
#if USE_TRAP
	SStackFrame	*ssp;

	ssp = tcb->isstack;
	--ssp;

	/* CPU context initialization */
	ssp->ps = INIT_PS;			/* Initial PSW */
	ssp->pc = tcb->task;		/* Task startup address */
	tcb->tskctxb.ssp = ssp;		/* System stack */
#endif
}

/*
 * Set task startup code
 *	Called by 'tk_sta_tsk()' processing.
 */
Inline void knl_setup_stacd( TCB *tcb, INT stacd )
{
#if USE_TRAP
	SStackFrame	*ssp = tcb->tskctxb.ssp;

	ssp->r[4] = stacd;
	ssp->r[5] = (VW)tcb->exinf;
#else
	SStackFrame	*ssp;

	ssp = tcb->isstack;
	--ssp;

	/* CPU context initialization */
	ssp->ps = INIT_PS;			/* Initial PSW */
	ssp->pc = tcb->task;		/* Task startup address */
	tcb->tskctxb.ssp = ssp;		/* System stack */

	ssp->r[4] = stacd;
	ssp->r[5] = (VW)tcb->exinf;
#endif
}

/*
 * Delete task contexts
 */
Inline void knl_cleanup_context( TCB *tcb )
{
	/* None */
}

#endif
