/*
 *----------------------------------------------------------------------
 *    micro T-Kernel
 *
 *    Copyright (C) 2006-2007 by Ken Sakamura. All rights reserved.
 *    micro T-Kernel is distributed under the micro T-License.
 *----------------------------------------------------------------------
 *    SOFTUNE micro T-REALOS/FR
 *
 *    Copyright (C) FUJITSU LIMITED 2006-2007 All rights reserved.
 *    This product uses the Source Code of micro T-Kernel under the micro 
 *    T-License granted by the T-Engine forum (http://www.t-engine.org). 
 *                                             Last update : 2007/03/26
 *----------------------------------------------------------------------
 *
 *    Version:   1.00.00
 *    Released by T-Engine Forum(http://www.t-engine.org) at 2007/03/26.
 *
 *----------------------------------------------------------------------
 */

/*
 *	tkdev_timer.h (FR)
 *	Hardware-Dependent Timer Processing
 */

#ifndef _TKDEV_TIMER_
#define	_TKDEV_TIMER_

/*
 * Settable interval range (millisecond)
 */
#define	MIN_TIMER_PERIOD	1
#define	MAX_TIMER_PERIOD	50

IMPORT void knl_start_hw_timer( void );
IMPORT void knl_clear_hw_timer_interrupt( void );
IMPORT void knl_end_of_hw_timer_interrupt( void );
IMPORT void knl_terminate_hw_timer( void );
IMPORT UW knl_get_hw_timer_nsec( void );

#endif
