/*
 *----------------------------------------------------------------------
 *    SOFTUNE micro T-REALOS/FR
 *
 *    Copyright (C) FUJITSU LIMITED 2006-2007 All rights reserved.
 *    This product uses the Source Code of micro T-Kernel under the micro 
 *    T-License granted by the T-Engine forum (http://www.t-engine.org). 
 *                                             Last update : 2007/03/26
 *----------------------------------------------------------------------
 */

/*
 * Systemcall Hook function
 *   0: Invalid
 *   1: Valid
 */
#define		USE_DBGSPT (0)
